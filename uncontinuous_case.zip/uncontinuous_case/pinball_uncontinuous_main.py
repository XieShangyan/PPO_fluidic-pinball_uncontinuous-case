import torch
import torch.nn as nn
from torch.distributions import MultivariateNormal
import numpy as np
import pinball_uncontinuous
import matplotlib.pyplot as plt
import pandas as pd
import os
import time
import shutil
#from openpyxl.workbook import Workbook
#from openpyxl.utils import get_column_letter
#from openpyxl.reader.excel import load_workbook

#from scipy import io
torch.set_default_tensor_type(torch.FloatTensor)
# train_data_split = torch.from_numpy(train_data_split).float()
#device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
device = torch.device("cpu")

#global reward
#global done
# env
# append

class Memory:
    def __init__(self):
        self.actions = []
        self.states = []
        self.logprobs = []
        self.rewards = []
        self.is_terminals = []
    
    def clear_memory(self):
        del self.actions[:]
        del self.states[:]
        del self.logprobs[:]
        del self.rewards[:]
        del self.is_terminals[:]

class ActorCritic(nn.Module):
    def __init__(self, state_dim, action_dim, action_std_init):
        super(ActorCritic, self).__init__()

        self.action_dim = action_dim

        # action mean range -1 to 1
        self.actor =  nn.Sequential(
                nn.Linear(state_dim, 512),
                nn.Tanh(),
                nn.Linear(512, 128),
                nn.Tanh(),
                nn.Linear(128, action_dim),
                nn.Tanh()
                )
        # critic
        self.critic = nn.Sequential(
                nn.Linear(state_dim, 512),
                nn.Tanh(),
                nn.Linear(512, 128),
                nn.Tanh(),
                nn.Linear(128, 1)
                )
        self.action_var = torch.full((action_dim,), action_std_init*action_std_init).to(device)
       
    def forward(self):
        raise NotImplementedError
    
    def act(self, state, memory):
        action_mean = self.actor(state)
        cov_mat = torch.diag(self.action_var).unsqueeze(dim=0)
        
        dist = MultivariateNormal(action_mean, cov_mat)
        action = dist.sample()
        action_logprob = dist.log_prob(action)
        
        memory.states.append(state)
        memory.actions.append(action)
        memory.logprobs.append(action_logprob)
        
        return action.detach(), action_logprob.detach()
    
    def evaluate(self, state, action):
        action_mean = self.actor(state)
        
        action_var = self.action_var.expand_as(action_mean)
        cov_mat = torch.diag_embed(action_var).to(device)
        
        dist = MultivariateNormal(action_mean, cov_mat)

        if self.action_dim ==1:                           #update
            action = action.reshape(-1, self.action_dim)

        action_logprobs = dist.log_prob(action)
        dist_entropy = dist.entropy()
        state_values = self.critic(state)
        
        return action_logprobs, state_values, dist_entropy

class PPO:
    
    def __init__(self, state_dim, action_dim, lr_actor, lr_critic, gamma, K_epochs, eps_clip, action_std_init=0.2):
        #self.lr = lr
        #self.betas = betas
        self.action_std = action_std_init
        self.gamma = gamma
        self.eps_clip = eps_clip
        self.K_epochs = K_epochs
        
        self.policy = ActorCritic(state_dim, action_dim, action_std_init).to(device)
        self.optimizer = torch.optim.Adam([
                        {'params': self.policy.actor.parameters(), 'lr': lr_actor},
                        {'params': self.policy.critic.parameters(), 'lr': lr_critic}
                    ])
        
        self.policy_old = ActorCritic(state_dim, action_dim, action_std_init).to(device)
        self.policy_old.load_state_dict(self.policy.state_dict())
        
        self.MseLoss = nn.MSELoss()

    def set_action_std(self, new_action_std):  # update
        self.action_std = new_action_std
        self.policy.set_action_std(new_action_std)
        self.policy_old.set_action_std(new_action_std)

    def decay_action_std(self, action_std_decay_rate, min_action_std):  # update
        self.action_std = self.action_std - action_std_decay_rate
        self.action_std = round(self.action_std, 4)
        if (self.action_std <= min_action_std):
            self.action_std = min_action_std
            print("setting actor output min_action_std to :", self.action_std)
        else:
            print("setting actor output action_std to:", self.action_std)
    
    def select_action(self, state, memory):
        # state = np.concatenate(state, axis=0)
        with torch.no_grad():
            state = state.astype(np.float)
            state = torch.FloatTensor(state.reshape(1, -1)).to(device)
            action, action_logprob = self.policy_old.act(state, memory)
        return action.detach().cpu().numpy().flatten()

    
    def update(self, memory):
        # Monte Carlo estimate of rewards:
        rewards = []
        discounted_reward = 0
        for reward, is_terminal in zip(reversed(memory.rewards), reversed(memory.is_terminals)):
            if is_terminal:
                discounted_reward = 0
            discounted_reward = reward + (self.gamma * discounted_reward)
            rewards.insert(0, discounted_reward)
        
        # Normalizing the rewards:
        rewards = torch.tensor(rewards, dtype=torch.float32).to(device)
        rewards = (rewards - rewards.mean()) / (rewards.std() + 1e-7)
        #rewards = np.repeat(rewards, 2, axis=None)
        
        # convert list to tensor
        old_states = torch.squeeze(torch.stack(memory.states, dim=0)).detach().to(device)
        old_actions = torch.squeeze(torch.stack(memory.actions, dim=0)).detach().to(device)
        old_logprobs = torch.squeeze(torch.stack(memory.logprobs, dim=0)).detach().to(device)
        
        # Optimize policy for K epochs:
        for _ in range(self.K_epochs):
            # Evaluating old actions and values :
            logprobs, state_values, dist_entropy = self.policy.evaluate(old_states, old_actions)

            # match state_values tensor dimensions with rewards tensor
            state_values = torch.squeeze(state_values)
            
            # Finding the ratio (pi_theta / pi_theta__old):
            ratios = torch.exp(logprobs - old_logprobs.detach())

            # Finding Surrogate Loss:
            advantages = rewards - state_values.detach()    #attention the rewards and state_valus must have the same dimention
            surr1 = ratios * advantages
            surr2 = torch.clamp(ratios, 1-self.eps_clip, 1+self.eps_clip) * advantages
            # loss = -torch.min(surr1, surr2) + 0.5*self.MseLoss(state_values, rewards) - 0.01*dist_entropy
            loss = -torch.min(surr1, surr2) + 0.5*self.MseLoss(state_values, rewards) - 0.01*dist_entropy
            
            # take gradient step
            self.optimizer.zero_grad()
            loss.mean().backward()
            self.optimizer.step()
            
        # Copy new weights into old policy:
        self.policy_old.load_state_dict(self.policy.state_dict())
        
def main():
    ############## Hyperparameters ##############
    env_name = 'pinball_uncontinuous'
    render = False
    solved_reward = 390         # stop training if running_reward > solved_reward
    log_interval = 20           # print avg reward in the interval
    max_episodes = 1000        # max training episodes
    max_timesteps = 10        # max timesteps in one episode
    
    update_timestep = 10      # update policy every n timesteps
    
    action_std = 0.2                # constant std for action distribution (Multivariate Normal)
    action_std_decay_rate = 0.005   # linearly decay action_std
    min_action_std = 0.001           # minimum action_std
    action_std_decay_freq = 10       # action_std decay frequency (in num tiomesteps)
    
    K_epochs = 4               # update policy for K epochs
    eps_clip = 0.2              # clip parameter for PPO
    gamma = 0.99                # discount factor
    #lr = 0.0002                 # parameters for Adam optimizer
    #betas = (0.9, 0.999)
    lr_actor = 0.0003
    lr_critic = 0.001
    
    random_seed = None
    #############################################
    
    # creating environment
    env = pinball_uncontinuous.env()
    state_dim = env.n_features
    action_dim = env.n_actions

    # unforced baseline #    
    with open("/home/caslx/Shane/uncontinuous_case/parameter_list.txt", "w") as f:
        f.write("0 0 0\n")
        f.close()
    for i_episode in range(1, 2):

        os.system("/home/caslx/Shane/uncontinuous_case/run.sh")
        dirname = "/home/caslx/Shane/uncontinuous_case/testCase/1/150"
        while not os.path.exists(dirname):
            time.sleep(15)
            # print('wait')

        episode_filename = '/home/caslx/Shane/uncontinuous_case/all_episode/episode' + str(i_episode)
        os.makedirs(episode_filename)
        with open("/home/caslx/Shane/uncontinuous_case/action.txt", "a") as f00:
            f00.write("0 0 0\n")

        mkpath = episode_filename + '/'
        with open(mkpath + 'action_in_episode' + ".txt", "a") as f01:
            f01.write("0 0 0\n")

        f02 = np.loadtxt(
            '/home/caslx/Shane/uncontinuous_case/testCase/1/postProcessing/forceCoeffs1/0/forceCoeffs.dat',
            comments='#', skiprows=1)  # file path must be change in right way
        C_d1 = np.mean(f02[120:148, 2])
        C_l1 = np.mean(f02[120:148, 3])
        f03 = np.loadtxt(
            '/home/caslx/Shane/uncontinuous_case/testCase/1/postProcessing/forceCoeffs2/0/forceCoeffs.dat',
            comments='#', skiprows=1)  # file path must be change in right way
        C_d2 = np.mean(f03[120:148, 2])
        C_l2 = np.mean(f03[120:148, 3])
        f04 = np.loadtxt(
            '/home/caslx/Shane/uncontinuous_case/testCase/1/postProcessing/forceCoeffs3/0/forceCoeffs.dat',
            comments='#', skiprows=1)  # file path must be change in right way
        C_d3 = np.mean(f04[120:148, 2])
        C_l3 = np.mean(f04[120:148, 3])
        C_d_sum = C_d1 + C_d2 + C_d3
        C_l_sum = C_l1 + C_l2 + C_l3
        R_func = 3.8 - C_d_sum - 0.5*abs(C_l_sum)
        with open("/home/caslx/Shane/uncontinuous_case/episode_mean.txt", "a") as f05:
            f05.write(
                "{}   {}   {}   {}   {}    {}    {}    {}    {}\n".format(C_d1, C_d2, C_d3, C_d_sum, C_l1, C_l2, C_l3,
                                                                          C_l_sum, R_func))

        time.sleep(1)
        os.system("/home/caslx/Shane/uncontinuous_case/remove.sh")
        time.sleep(2)

    os.system("/home/caslx/Shane/uncontinuous_case/run.sh")
    dirname = "/home/caslx/Shane/uncontinuous_case/testCase/1/150"
    while not os.path.exists(dirname):
        time.sleep(15)
        print('wait')

    if random_seed:
        print("Random Seed: {}".format(random_seed))
        torch.manual_seed(random_seed)
        env.seed(random_seed)
        np.random.seed(random_seed)
    
    memory = Memory()

    # initialize a ppo agent
    ppo = PPO(state_dim, action_dim, lr_actor, lr_critic, gamma, K_epochs, eps_clip, action_std)

    
    # logging variables
    running_reward = 0
    avg_length = 0
    time_step = 0
   
    # training loop
    for i_episode in range(2, max_episodes+1):
        state = env.reset()
        running_reward = 0
        episode_filename = '/home/caslx/Shane/uncontinuous_case/all_episode/episode' + str(i_episode)
        os.makedirs(episode_filename)
        for t in range(max_timesteps):
            time_step += 1
            # Running policy_old:
            [action0_array, action1_array, action2_array] = ppo.select_action(state, memory)
            action0 = action0_array
            action0 = np.clip(action0, -2, 2)
            action1 = - 2 * abs(action1_array)
            action1 = np.clip(action1, -2, 2)
            action2 = 2 * abs(action2_array)
            action2 = np.clip(action2, -2, 2)
            with open("/home/caslx/Shane/uncontinuous_case/action.txt", "a") as f6:
                f6.write("{} {} {}\n".format(action0, action1, action2))

            #state, reward, done, _ = env.step(action0, action1, action2)

            ###写入b1,b2到parameter_list####

            time.sleep(1)
            os.system("/home/caslx/Shane/uncontinuous_case/remove.sh")
            time.sleep(2)
            
            with open("/home/caslx/Shane/uncontinuous_case/parameter_list.txt", "a") as f3:
                f3.seek(0)
                f3.truncate()
                f3.write("{} {} {}\n".format(action0, action1, action2))
                time.sleep(1)
                print('parameter undate successfully')
                
            os.system("/home/caslx/Shane/uncontinuous_case/run.sh")
            dirname="/home/caslx/Shane/uncontinuous_case/testCase/1/150"
            while not os.path.exists(dirname):
                time.sleep(2)

            print('simulation again successfully')

            state, reward, done, _ = env.step(action0, action1, action2)
                
            # Saving reward and is_terminals:
            
            memory.rewards.append(reward)
            memory.is_terminals.append(done)

            mkpath = episode_filename + '/'
            with open(mkpath + 'action_in_episode' + ".txt", "a") as f13:
                f13.write("{} {} {}\n".format(action0, action1, action2))
            
            # update if its time
            if time_step % update_timestep == 0:
                print('update')
                ppo.update(memory)
                memory.clear_memory()
                #time_step = 0
                
            running_reward += reward
            
            if time_step % action_std_decay_freq == 0:
                ppo.decay_action_std(action_std_decay_rate, min_action_std)
                
            if render:
                env.render()
            if done:
                break


        with open("/home/caslx/Shane/uncontinuous_case/reward.txt", "a") as f12:
            f12.write("{} \n".format(running_reward))

        filename = "/home/caslx/Shane/uncontinuous_case/mean_coefficient.txt"
        myfile = open(filename)
        shutil.copy(filename, episode_filename)
        n = len(myfile.readlines())
        if n <= 2:
            f7 = np.loadtxt('/home/caslx/Shane/uncontinuous_case/mean_coefficient.txt')
            f7 = f7.reshape(1, -1)
            C_d1_episode = f7[0, 0]
            C_d2_episode = f7[0, 1]
            C_d3_episode = f7[0, 2]
            C_d_sum_episode = f7[0, 3]
            C_l1_episode = f7[0, 4]
            C_l2_episode = f7[0, 5]
            C_l3_episode = f7[0, 6]
            C_l_sum_episode = f7[0, 7]
            R_func_episode = f7[0, 8]
            with open("/home/caslx/Shane/uncontinuous_case/episode_mean.txt", "a") as f8:
                f8.write("{}    {}    {}    {}    {}    {}    {}    {}    {}\n".format(C_d1_episode, C_d2_episode, C_d3_episode,
                                                                                       C_d_sum_episode, C_l1_episode, C_l2_episode,
                                                                                       C_l3_episode, C_l_sum_episode, R_func_episode))

        else:
            f9 = np.loadtxt('/home/caslx/Shane/uncontinuous_case/mean_coefficient.txt')
            C_d1_episode = np.mean(f9[:, 0])
            C_d2_episode = np.mean(f9[:, 1])
            C_d3_episode = np.mean(f9[:, 2])
            C_d_sum_episode = np.mean(f9[:, 3])
            C_l1_episode = np.mean(f9[:, 4])
            C_l2_episode = np.mean(f9[:, 5])
            C_l3_episode = np.mean(f9[:, 6])
            C_l_sum_episode = np.mean(f9[:, 7])
            R_func_episode = np.mean(f9[:, 8])
            with open("/home/caslx/Shane/uncontinuous_case/episode_mean.txt", "a") as f10:
                f10.write("{}    {}    {}    {}    {}    {}    {}    {}    {}\n".format(C_d1_episode, C_d2_episode, C_d3_episode,
                                                                                       C_d_sum_episode, C_l1_episode, C_l2_episode,
                                                                                       C_l3_episode, C_l_sum_episode, R_func_episode))

        with open("/home/caslx/Shane/uncontinuous_case/mean_coefficient.txt", "a") as f11:
            f11.seek(0)
            f11.truncate()
            f11.close()
            
        # record episode mean power J and clean the file
        f12 = np.loadtxt('/home/caslx/Shane/uncontinuous_case/power.txt')
        J_episode = np.mean(f12[:, 0])
        Ja_episode = np.mean(f12[:, 1])
        Jb_episode = np.mean(f12[:, 2])
        with open("/home/caslx/Shane/uncontinuous_case/power_mean.txt", "a") as f13:
            f13.write("{}    {}    {}\n".format(J_episode, Ja_episode, Jb_episode))
        with open("/home/caslx/Shane/uncontinuous_case/power.txt", "a") as f14:
            f14.seek(0)
            f14.truncate()
            f14.close()
        

        avg_length += t
        
         #stop training if running_reward > solved_reward
        if running_reward > (log_interval*solved_reward):
            print("########## Solved! ##########")
            #x_axis = [x for x in range(len(env.his_b1))]
            #plt.plot(x_axis, env.his_b1)
            #plt.xlabel('t')
            #plt.ylabel('v1')
            #plt.plot(x_axis, env.his_b2)
            #plt.xlabel('t')
            #plt.ylabel('v2')
            #plt.show()
            # plt.plot(x_axis, env.his_a1)
            # plt.xlabel('t')
            # plt.ylabel('C_d')
            # plt.show()
            # plt.plot(x_axis, env.his_a2)
            # plt.xlabel('t')
            # plt.ylabel('C_l')
            # plt.show()
            # plt.plot(env.his_a1, env.his_a2)
            # plt.xlabel('C_d')
            # plt.ylabel('C_l')
            #plt.show()
            #print(env.his_b1)
            #print(env.his_b2)
            # print(env.his_a2)
            # print(env.his_a1)
            torch.save(ppo.policy.state_dict(), './PPO_continuous_solved_{}.pth'.format(env_name))
            #b1_data = pd.DataFrame(columns=None, data=env.his_b1)
            #b1_data.to_txt('/home/caslx/Shane/uncontinuous_case/b1_data')
            #b2_data = pd.DataFrame(columns=None, data=env.his_b2)
            #b2_data.to_txt('/home/caslx/Shane/uncontinuous_case/b2_data')
            # a1_data = pd.DataFrame(columns=None, data=env.his_a1)
            # a1_data.to_excel('/home/dyfluid/case/a1_data.txt')
            # a2_data = pd.DataFrame(columns=None, data=env.his_a2)
            # a2_data.to_excel('/home/dyfluid/case/a2_data.txt')
            break
        
        # save every 500 episodes
        if i_episode % 50 == 0:
            torch.save(ppo.policy.state_dict(), './PPO_continuous_{}.pth'.format(env_name))
            
        # logging
        if i_episode % log_interval == 0:
            avg_length = int(avg_length/log_interval)
            running_reward = int((running_reward/log_interval))
            
            print('Episode {} \t Avg length: {} \t Running reward: {}'.format(i_episode, avg_length, running_reward))
            running_reward = 0
            avg_length = 0
            
if __name__ == '__main__':
    main()
    
