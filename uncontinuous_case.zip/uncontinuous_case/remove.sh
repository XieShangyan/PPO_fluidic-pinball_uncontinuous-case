cd /home/caslx/Shane/uncontinuous_case138/testCase
ls
         
rm -r 1
#rm -r postProcessing
#for j in `seq 5`
    #do
    #rm -r $j
#done

echo "rename success!"   
