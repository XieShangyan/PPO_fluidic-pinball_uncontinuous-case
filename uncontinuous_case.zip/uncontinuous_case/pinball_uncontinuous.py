import numpy as np
import torch
#import time
#import sys
#import math
torch.set_default_tensor_type(torch.FloatTensor)


class env:
    def __init__(self):
        # self.a1 = 0      #Cd
        # self.a2 = 0           #Cl
        self.a = np.zeros((1,304))
        self.n_features = 304
        self.step_num = 0
        self.b1 = 0           #转速1
        self.b2 = 0           #转速2
        self.b3 = 0
        self.his_b1 = [self.b1]
        self.his_b2 = [self.b2]
        self.his_b3 = [self.b3]
        # self.his_a1 = [self.a1]
        # self.his_a2 = [self.a2]
        self.his_a = self.a
        self.n_actions = 3


    def reset(self):
        # self.a1 = 0
        # self.a2 = 0
        self.a = np.zeros((1,304))
        self.step_num = 0
        self.b1 = 0
        self.b2 = 0
        self.b3 = 0
        self.his_b1 = [self.b1]
        self.his_b2 = [self.b2]
        self.his_b3 = [self.b3]
        # self.his_a1 = [self.a1]
        # self.his_a2 = [self.a2]
        self.his_a = [self.a]
        # return np.array([self.a1, self.a2])
        return self.a 
    
    # def adv(self, p, C_d, C_l):
    #     f1 = np.loadtxt('/home/dyfluid/Desktop/front-(0 1 -1)', comments='#', skiprows=1)
    #     C_d = np.mean(f1[11:21,2])
    #     C_l = np.mean(f1[11:21,3])
        
    #     return p, C_d, C_l

    def step(self, action0, action1, action2):
        self.step_num += 1
        #global reward
        #global done
        #for n in range(1, 100):
            #f1 = np.loadtxt('/home/dyfluid/case/testCase/' + str(n) + '/postProcessing/forceCoeffs1/0/forceCoeffs.dat', comments='#', skiprows=1)
        # f1 = np.loadtxt('/home/dyfluid/case/testCase/1/postProcessing/forceCoeffs1/0/forceCoeffs.dat', comments='#', skiprows=1)
        # self.a1 = f1[2,2]
            #f1.close()
            #f2 = np.loadtxt('/home/dyfluid/case/testCase/' + str(n) + '/postProcessing/forceCoeffs1/0/forceCoeffs.dat', comments='#', skiprows=1)
        # f2 = np.loadtxt('/home/dyfluid/case/testCase/1/postProcessing/forceCoeffs1/0/forceCoeffs.dat', comments='#', skiprows=1)
        # self.a2 = f2[2,3]
            #f2.close()
        f11 = np.loadtxt('/home/caslx/Shane/uncontinuous_case/testCase/1/postProcessing/forceCoeffs1/0/forceCoeffs.dat', comments='#', skiprows=1)           #file path must be change in right way
        C_m1 = np.mean(f11[120:148, 1])
        C_d1 = np.mean(f11[120:148, 2])
        C_l1 = np.mean(f11[120:148, 3])
        f12 = np.loadtxt('/home/caslx/Shane/uncontinuous_case/testCase/1/postProcessing/forceCoeffs2/0/forceCoeffs.dat', comments='#', skiprows=1)  # file path must be change in right way
        C_m2 = np.mean(f12[120:148, 1])
        C_d2 = np.mean(f12[120:148, 2])
        C_l2 = np.mean(f12[120:148, 3])
        f13 = np.loadtxt('/home/caslx/Shane/uncontinuous_case/testCase/1/postProcessing/forceCoeffs3/0/forceCoeffs.dat', comments='#', skiprows=1)  # file path must be change in right way
        C_m3 = np.mean(f13[120:148, 1])
        C_d3 = np.mean(f13[120:148, 2])
        C_l3 = np.mean(f13[120:148, 3])

        C_d_sum = C_d1 + C_d2 + C_d3
        C_l_sum = C_l1 + C_l2 + C_l3

        f14 = np.loadtxt('/home/caslx/Shane/uncontinuous_case/parameter_list.txt')
        V1 = f14[0]
        V2 = f14[1]
        V3 = f14[2]
        Ja = C_d_sum / 2
        Jb = - ((V1*C_m1) + (V2*C_m2) + (V3*C_m3)) / 2

        R_func = 3.8 - C_d_sum - 0.5*abs(C_l_sum)


        with open("/home/caslx/Shane/uncontinuous_case/mean_coefficient.txt", "a") as f2:
            f2.write("{}   {}   {}   {}   {}    {}    {}    {}    {}\n".format(C_d1, C_d2, C_d3, C_d_sum, C_l1, C_l2, C_l3, C_l_sum, R_func))
        with open("/home/caslx/Shane/uncontinuous_case/num_timestep_coefficient.txt", "a") as f3:
            f3.write("{}   {}   {}   {}   {}    {}    {}    {}    {}\n".format(C_d1, C_d2, C_d3, C_d_sum, C_l1, C_l2, C_l3, C_l_sum, R_func))
        with open("/home/caslx/Shane/uncontinuous_case/power.txt", "a") as f4:
            f4.write("{}   {}   {} \n".format(Ja+Jb, Ja, Jb))
        with open("/home/caslx/Shane/uncontinuous_case/power_num.txt", "a") as f5:
            f5.write("{}   {}   {} \n".format(Ja+Jb, Ja, Jb))

        # self.a1 = C_d
        # self.a2 = C_l
        # tmp_a1 = C_d              #从文件读取Cd
        # tmp_a2 = C_l              #从文件读取Cl
        # s = np.array([self.a1, self.a2])
        # self.a1 = tmp_a1
        # self.a2 = tmp_a2
        # s_ = np.array([self.a1, self.a2])
       
        s = np.array(self.a, dtype = float)

        # # write pressure as state #
        # f4 = np.loadtxt('/home/caslx/Shane/uncontinuous_case/testCase/1/postProcessing/probes/0/p', comments='#', skiprows=1)     #file path must be change in right way
        # p_all = f4[31:46,1:154]
        # self.a = np.mean(p_all, 0)

        # write velovity as state #
        directory = "/home/caslx/Shane/uncontinuous_case/testCase/1/postProcessing/probes/0/U"
        with open(directory, "r") as f:  # 打开文件
            data = f.readlines()  # 读取文件
            data = data[155:]  # 只读取第155行之后的内容
            f = open(directory, "w")  # 以写入的形式打开txt文件
            f.writelines(data)  # 将修改后的文本内容写入
            f.close()  # 关闭文件

        f4 = open("/home/caslx/Shane/uncontinuous_case/testCase/1/postProcessing/probes/0/U", encoding="utf-8")
        str1 = f4.readline()
        U_all = []
        while str1:
            str_list = str1.split(sep=")")
            str_list = [i.replace("(", "").strip() for i in str_list]
            str_list = str_list[1:-1]
            str_list = [list(map(float, i.split(sep=" ")[:-1])) for i in str_list]
            U_all.append(str_list)
            str1 = f4.readline()
        f4.close()
        U_np = np.array(U_all)
        self.a = np.mean(U_np[120:148], 0)

        with open("/home/caslx/Shane/uncontinuous_case/state", "a") as f5:
            f5.seek(0)
            f5.truncate()
            f5.write("{}\n".format(self.a))
        # p_list = p.tolist()
        # list_a = self.a.tolist()
        # list_a.append(p)
        # self.a = p
        
        # self.a = np.array(list_a,dtype = float).reshape(12,12)
        # s_ = np.zeros((12,12))
        s_ = np.array(self.a, dtype = float)
        # s_ = np.concatenate(s_, axis=0)
        
        # self.his_a1.append(tmp_a1)
        # self.his_a2.append(tmp_a2)
        # his_list_a.append(list_a)
        # self.his_a = his_list_a
        #self.his_b1.append(action1[0])
        #self.his_b2.append(action2[0])
        reward = 0
        # tmp_reward_a1 = 0
        # tmp_reward_a2 = 0
        # for i, item in enumerate(self.his_a1):
        #     tmp_reward_a1 += item * item
        #     #tmp_reward_a1a2 += self.his_a2[i] * self.his_a2[i]
        #     tmp_reward_a2 += self.his_a2[i] * self.his_a2[i]
        # tmp_reward_a1 /= len(self.his_a1)
        # tmp_reward_a2 /= len(self.his_a2)
        
        # reward = - tmp_reward_a1 - abs(tmp_reward_a2)

        reward = 3.8 - C_d_sum - 0.5*abs(C_l_sum)
        done = False
        # if -1.8 < reward <= -1.7:
        #     reward = reward + 0.5
        #     done = False
        # elif -1.7 < reward <= -1.6:
        #     reward = reward + 1
        #     done = False
        # elif -1.6 < reward <= -1.5:
        #     reward = reward + 1.5
        #     done = False
        # elif -1.5 < reward <= -1.4:
        #     reward = reward + 2
        #     done = False
        # elif -1.4 < reward <= -1.3:
        #     reward = reward + 3
        #     done = False
        # elif -1.3 < reward <= -1.2:
        #     reward = reward + 6
        #     done = False
        # elif -1.2 < reward <= -1.1:
        #     reward = reward + 10
        #     done = False
        # elif -1.1 < reward <= -1:
        #     reward = reward + 15
        #     done = False
        # elif reward >= -1:
        #     reward = reward + 100
        #     done = False
        # else:
        #     reward = reward - 10
        #     done = False

        return s_, reward, done, s

    
