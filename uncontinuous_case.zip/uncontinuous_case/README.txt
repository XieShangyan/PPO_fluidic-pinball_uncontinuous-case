######################################
Writed by Xie Shangyan (Shane) in 801, T6 Buliding,
Harbin Institute of Technology, Shenzhen, China.
TIme: 2022-01-05
######################################

This part is associated with an uncontinuous case about the fluidic pinball control combined with PPO.
It could tame the fluidic pinball when the wake is steady.


Using method:
1-Modify the path to adpate your computer;
2-Load "pinball_uncontinuous.py";
3-Run "pinball_uncontinuous_main.py".
4-Noted that you need to clear the folder "all_episode" before running a new case, 
and don't delete some important and necessary files, "parameter_list.txt", "state.txt", "remove.sh", "run.sh".


Version:
Python 3.8.2
openFOAM-8