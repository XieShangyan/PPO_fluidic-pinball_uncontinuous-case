#!/bin/bash
# usage: ./xxx.sh, no parameter needed
# modify omega in file 0/U by data from parameter_list
# and run icoFoam

cd "${0%/*}" || exit 1

## set OpenFOAM enviroinment
source $HOME/OpenFOAM/OpenFOAM-8/etc/bashrc
#source /home/lin/openfoam/OpenFOAM-7/etc/bashrc

#
## Source run functions
. "$WM_PROJECT_DIR/bin/tools/RunFunctions"

pDir=$PWD

# set original case file name
orgFile="0"
#orgFile="orgCase/0"
if [ ! -d "$orgFile" ]; then
    echo "orgFile Directory: $orgFile not exist, please check."
    exit 1
fi

# set parameter file name
paraFile="parameter_list.txt"

caseDir="testCase"

#set -x

# read parameter file
i=0
while read -r line
#sleep 25
do
    ((i++))

    # for test, 10 case
    #if [ "$i" -gt 10 ]; then 
     #   break 
    #fi

    # read parameter
    w1=$(echo "$line" | awk '{print $1}' | awk '{printf("%.1f", $0)}')
    w2=$(echo "$line" | awk '{print $2}' | awk '{printf("%.1f", $0)}')
    w3=$(echo "$line" | awk '{print $3}' | awk '{printf("%.1f", $0)}')
    
    #echo "$w1" "$w2" "$w3"

    # new file name
    #newFile=$(echo "$w1"_"$w2"_"$w3") 
    #newFile=$(echo "$w1"a"$w2"a"$w3" | sed 's/\./p/g') 
    newFile=$i
    newFile=$caseDir/"$newFile"

    #echo $newFile

    if [ -d "$newFile" ]; then
        echo "Directory $newFile already exist, skip!"
        continue 
    fi

    # copy to new file
    mkdir -p "$newFile"
    cp -r "${orgFile}"/* "$newFile"

    # U file directory
    uFile="$newFile""/0/U"
    #
    reg="omega"

    # modify U file
    k=0

    for j in $(cat -n "$uFile" | grep $reg | awk '{print $1}')
    do
        ((k++))

        var=w$k
        #
        sed -i ''"${j}"'c '"$reg ${!var}"';' "$uFile"
    done
done < $paraFile

for calcDir in "$pDir"/"$caseDir"/* 
do
    
    # store jobs id in array joblist
    #joblist=($(jobs -p))
    mapfile -t joblist < <(jobs -p)
    #echo joblist=${joblist[*]}

    # limit number of job(s) to 1
    njobs=2

    # compare joblist size and limited number of job(s)
    while ((${#joblist[*]} >= njobs))
    do
        wait -n
        mapfile -t joblist < <(jobs -p)
        #declare -p joblist
    done

    # goto working directory
    echo "cd $calcDir"
    cd "$calcDir" || { echo "$calcDir not exist. skip"; continue;}

    # run icoFoam
    runApplication icoFoam &
    
    mapfile -t joblist < <(jobs -p)
    echo "joblist: " ${joblist[*]}
done
